from __future__ import annotations

import math
import random
from statistics import mean as statistics_mean
from statistics import pstdev


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def safe_percent(value: float, total: float) -> float:
    if total == 0:
        return 0.0
    return value / total * 100.0


def mean(values: list[float]) -> float:
    return float(statistics_mean(values)) if values else 0.0


def stdev(values: list[float]) -> float:
    return float(pstdev(values)) if len(values) > 1 else 0.0


def trend(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    n = len(values)
    x_mean = (n - 1) / 2
    y_mean = mean(values)
    numerator = sum((i - x_mean) * (value - y_mean) for i, value in enumerate(values))
    denominator = sum((i - x_mean) ** 2 for i in range(n))
    if denominator == 0:
        return 0.0
    return numerator / denominator


def exponential_minutes(mtbf_minutes: float) -> float:
    return max(1.0, random.expovariate(1.0 / mtbf_minutes))


def ease_towards(current: float, target: float, strength: float) -> float:
    return current + (target - current) * clamp(strength, 0.0, 1.0)


def format_currency(value: float) -> str:
    sign = "" if value >= 0 else "−"
    value = abs(value)
    if value >= 1_000_000:
        return f"{sign}{value / 1_000_000:.1f} Mkr"
    if value >= 10_000:
        return f"{sign}{value / 1000:.0f} tkr"
    if value >= 1000:
        return f"{sign}{value / 1000:.1f} tkr"
    return f"{sign}{value:.0f} kr"


def rounded_int(value: float) -> int:
    return int(math.floor(value + 0.5))
