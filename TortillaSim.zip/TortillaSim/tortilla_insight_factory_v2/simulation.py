from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Literal

from model import PredictiveMaintenanceModel
from settings import EconomySettings, ModelSettings, OvenSettings, ProductionSettings
from storage import ProductionStorage
from utils import clamp, ease_towards, exponential_minutes, rounded_int, safe_percent

LineStatus = Literal["RUNNING", "WARNING", "STOPPED"]


@dataclass
class MachineStage:
    name: str
    mtbf_minutes: float
    mttr_minutes: float
    criticality: float
    operator_note: str
    health: float = 100.0
    running: bool = True
    downtime_left: float = 0.0
    next_failure_in: float = 0.0
    last_issue: str = "Normal drift"

    def __post_init__(self) -> None:
        if self.next_failure_in <= 0:
            self.next_failure_in = exponential_minutes(self.mtbf_minutes)


@dataclass
class LineState:
    minute: int = 0
    sku: str = "6 pack"
    line_status: LineStatus = "RUNNING"
    ai_active: bool = True
    ai_cooldown: int = 0
    packs_six: int = 0
    packs_twelve: int = 0
    pallets_done: int = 0
    pallet_cartons: int = 0
    pallet_layers: int = 0
    belt_speed: float = ProductionSettings().default_belt_speed
    flow_kg_minute: float = ProductionSettings().default_flow_kg_minute
    humidity: float = ProductionSettings().default_humidity
    dough_temp: float = 24.5
    line_pressure: float = 48.0
    quality_score: float = 96.0
    film_left: int = ProductionSettings().film_roll_length
    oven_zones: list[float] = field(default_factory=lambda: [188.0, 211.0, 201.0])
    risk_probability: float = 0.10
    downtime_minutes: int = 0
    unplanned_stops: int = 0
    prevented_stops: int = 0
    avoided_downtime_minutes: int = 0
    waste_packs: int = 0
    energy_kwh: float = 0.0
    packs_last_minute: int = 0

    @property
    def packs_total(self) -> int:
        return self.packs_six + self.packs_twelve


class TortillaFactorySimulation:
    """Runs the production, data, AI and economy logic behind the dashboard."""

    def __init__(self) -> None:
        self.production = ProductionSettings()
        self.oven = OvenSettings()
        self.model_settings = ModelSettings()
        self.economy_settings = EconomySettings()
        self.storage = ProductionStorage()
        self.model = PredictiveMaintenanceModel(self.model_settings)
        self.state = LineState()
        self.history: list[dict] = []
        self.events: list[dict] = []
        self.last_help_message = "Välj en vy i toppen eller klicka på informationssymbolen vid en knapp."
        self.stages = self._build_stages()
        self.record_event("SYSTEM", "Line", "Dashboard startad med AI prevention aktiv")

    def _build_stages(self) -> list[MachineStage]:
        return [
            MachineStage("Råvaror", 2600, 8, 0.65, "Dosering och materialflöde"),
            MachineStage("Mixer", 2400, 12, 0.75, "Degblandning och fuktnivå"),
            MachineStage("Formare", 2200, 10, 0.82, "Formning och viktvariation"),
            MachineStage("Ugn", 2100, 15, 1.00, "Temperatur och bakprofil"),
            MachineStage("Kylning", 2700, 9, 0.55, "Stabilisering efter bakning"),
            MachineStage("Påspackare", 1900, 18, 0.95, "Film, takt och packflöde"),
            MachineStage("Robot", 2300, 11, 0.72, "Lyft och placering"),
            MachineStage("Kartong", 2600, 10, 0.60, "Kartongbildning och etikett"),
            MachineStage("Pall", 3000, 8, 0.50, "Pallmönster och lager"),
        ]

    def reset(self) -> None:
        self.storage.close()
        self.__init__()
        self.record_event("CONTROL", "Operator", "Simuleringen återställdes")

    def tick(self) -> None:
        s = self.state
        s.minute += 1
        s.packs_last_minute = 0
        if s.ai_cooldown > 0:
            s.ai_cooldown -= 1

        self._update_sku()
        self._update_repair_work()
        self._update_process_conditions()
        features = self.model.build_features(self.history, [stage.health for stage in self.stages])
        risk = self.model.predict(features)
        s.risk_probability = risk
        s.line_status = self._line_status_from_risk(risk)

        action_taken = False
        if s.ai_active and risk >= self.model_settings.action_threshold and s.ai_cooldown == 0:
            action_taken = self.apply_preventive_action(source="AI")

        stop_happened = self._maybe_create_stop(risk, action_taken)
        self._produce_if_possible(risk)
        self._update_label_and_model(features, risk, stop_happened)

        row = self._telemetry_row()
        economy = self.economy_snapshot()
        row["net_value"] = economy["net_value"]
        self.history.append(row)
        self.storage.save_telemetry(row)
        if s.minute % 5 == 0:
            self.storage.save_economy(economy)

    def toggle_ai(self) -> None:
        self.state.ai_active = not self.state.ai_active
        state = "aktiv" if self.state.ai_active else "inaktiv"
        self.record_event("CONTROL", "AI", f"AI prevention är nu {state}")

    def adjust_speed_percent(self, delta_percent: float) -> None:
        s = self.state
        current_factor = s.belt_speed / self.production.default_belt_speed
        target_factor = clamp(
            current_factor + delta_percent / 100.0,
            self.production.minimum_speed_factor,
            self.production.maximum_speed_factor,
        )
        s.belt_speed = self.production.default_belt_speed * target_factor
        self.record_event("CONTROL", "Operator", f"Bandhastighet ändrad till {self.speed_change_percent():+.0f} procent mot standard")

    def inject_fault(self) -> None:
        stage = random.choice(self.stages[2:7])
        stage.health = clamp(stage.health - random.uniform(22, 38), 0, 100)
        stage.last_issue = "Testat fel injicerat manuellt"
        self.record_event("TEST", stage.name, "Ett kontrollerat fel injicerades för att testa riskmodellen")

    def all_running(self) -> bool:
        return all(stage.running for stage in self.stages)

    def speed_change_percent(self) -> float:
        return (self.state.belt_speed / self.production.default_belt_speed - 1.0) * 100.0

    def throughput_lift_percent(self) -> float:
        current = self.current_packs_per_hour()
        return safe_percent(current - self.production.baseline_packs_per_hour, self.production.baseline_packs_per_hour)

    def current_packs_per_hour(self) -> float:
        if self.state.minute <= 0:
            return self.production.baseline_packs_per_hour
        recent = self.history[-60:]
        if not recent:
            return self.production.baseline_packs_per_hour
        produced = recent[-1]["packs_total"] - recent[0]["packs_total"] if len(recent) > 1 else self.state.packs_last_minute
        minutes = max(1, len(recent) - 1)
        return produced / minutes * 60.0

    def economy_snapshot(self) -> dict[str, float]:
        s = self.state
        elapsed = max(1, s.minute)
        baseline_packs = self.production.baseline_packs_per_minute * elapsed
        extra_packs = s.packs_total - baseline_packs
        extra_margin = extra_packs * self.economy_settings.contribution_margin_per_pack
        avoided_value = s.avoided_downtime_minutes * self.economy_settings.downtime_cost_per_minute
        waste_cost = s.waste_packs * self.economy_settings.waste_cost_per_pack
        baseline_energy = self.economy_settings.baseline_energy_kwh_per_minute * elapsed
        extra_energy = max(0.0, s.energy_kwh - baseline_energy)
        energy_cost = extra_energy * self.economy_settings.energy_cost_per_kwh
        net_value = extra_margin + avoided_value - waste_cost - energy_cost
        return {
            "minute": float(s.minute),
            "baseline_packs": baseline_packs,
            "current_packs": float(s.packs_total),
            "extra_packs": extra_packs,
            "extra_margin": extra_margin,
            "avoided_downtime_value": avoided_value,
            "waste_cost": waste_cost,
            "energy_cost": energy_cost,
            "net_value": net_value,
        }

    def apply_preventive_action(self, source: str = "Operator") -> bool:
        s = self.state
        if s.ai_cooldown > 0 and source == "AI":
            return False

        features = self.model.last_features
        weakest = min(self.stages, key=lambda stage: stage.health)
        action_message = "Förebyggande åtgärd utförd"

        if features:
            film_ratio = features[21]
            oven_gap = features[22]
            line_pressure = features[26]
            quality_score = features[32]
            if film_ratio < 0.20:
                s.film_left = self.production.film_roll_length
                action_message = "Planerat filmbyte genomfört innan påspackaren stoppade"
            elif oven_gap > 5.5:
                self._stabilize_oven()
                action_message = "Ugnszoner justerades tillbaka mot processfönster"
            elif line_pressure > 70.0:
                self.adjust_speed_percent(-3.0)
                action_message = "Takten balanserades för att minska linjetryck"
            elif quality_score < 83.0:
                s.humidity = ease_towards(s.humidity, self.production.default_humidity, 0.35)
                s.dough_temp = ease_towards(s.dough_temp, 24.5, 0.35)
                action_message = "Processfönster justerades för att skydda kvalitet"
            else:
                weakest.health = clamp(weakest.health + 16, 0, 100)
                weakest.last_issue = "Mikroservice utförd"
                action_message = f"Mikroservice utförd på {weakest.name}"
        else:
            weakest.health = clamp(weakest.health + 12, 0, 100)

        s.prevented_stops += 1
        s.avoided_downtime_minutes += int(max(4, weakest.mttr_minutes * 0.55))
        s.ai_cooldown = 16 if source == "AI" else 8
        self.record_event("PREVENTED", source, action_message)
        return True

    def _update_sku(self) -> None:
        if self.state.minute % 180 == 0:
            self.state.sku = "12 pack" if self.state.sku == "6 pack" else "6 pack"
            self.record_event("BATCH", "Planering", f"Batch växlade till {self.state.sku}")

    def _update_repair_work(self) -> None:
        s = self.state
        for stage in self.stages:
            if stage.running:
                continue
            stage.downtime_left -= 1
            s.downtime_minutes += 1
            if stage.downtime_left <= 0:
                stage.running = True
                stage.health = clamp(stage.health + random.uniform(18, 32), 45, 100)
                stage.next_failure_in = exponential_minutes(stage.mtbf_minutes)
                stage.last_issue = "Återstart efter stopp"
                self.record_event("RESTART", stage.name, "Stationen är tillbaka i drift")

    def _update_process_conditions(self) -> None:
        s = self.state
        speed_factor = s.belt_speed / self.production.default_belt_speed
        weakest_health = min(stage.health for stage in self.stages)

        s.humidity = clamp(
            ease_towards(s.humidity, self.production.default_humidity + random.uniform(-2.2, 2.2), 0.08),
            26.0,
            45.0,
        )
        s.flow_kg_minute = clamp(
            ease_towards(s.flow_kg_minute, self.production.default_flow_kg_minute * speed_factor + random.uniform(-2.0, 2.0), 0.20),
            34.0,
            78.0,
        )
        s.dough_temp = clamp(
            ease_towards(s.dough_temp, 24.5 + (s.humidity - 35.0) * 0.05 + random.uniform(-0.8, 0.8), 0.12),
            20.0,
            31.0,
        )
        s.line_pressure = clamp(
            ease_towards(s.line_pressure, 46.0 + (speed_factor - 1.0) * 54.0 + (100.0 - weakest_health) * 0.28 + random.uniform(-4.0, 4.0), 0.16),
            30.0,
            95.0,
        )

        for index, setpoint in enumerate(self.oven.zone_setpoints):
            stress = (speed_factor - 1.0) * (3.0 + index)
            random_drift = random.uniform(-1.6, 1.6)
            target = setpoint + stress + random_drift
            s.oven_zones[index] = clamp(ease_towards(s.oven_zones[index], target, 0.09), 170.0, 232.0)

        oven_gap = max(abs(zone - setpoint) for zone, setpoint in zip(s.oven_zones, self.oven.zone_setpoints))
        humidity_gap = abs(s.humidity - self.production.default_humidity)
        pressure_penalty = clamp((s.line_pressure - 65.0) * 0.35, 0.0, 12.0)
        speed_penalty = clamp((speed_factor - 1.08) * 28.0, 0.0, 8.0)
        s.quality_score = clamp(97.0 - oven_gap * 1.35 - humidity_gap * 0.45 - pressure_penalty - speed_penalty + random.uniform(-1.4, 1.4), 48.0, 99.0)

        for stage in self.stages:
            if not stage.running:
                continue
            stress = max(0.0, speed_factor - 1.0) * 0.030 * stage.criticality
            pressure_stress = max(0.0, s.line_pressure - 68.0) * 0.0025 * stage.criticality
            random_wear = random.uniform(0.006, 0.045) * stage.criticality
            stage.health = clamp(stage.health - stress - pressure_stress - random_wear, 0, 100)
            stage.next_failure_in -= max(0.35, speed_factor * stage.criticality)

        s.energy_kwh += max(0.0, 3.0 + speed_factor * 2.2 + max(0, s.line_pressure - 55.0) * 0.025)

    def _line_status_from_risk(self, risk: float) -> LineStatus:
        if not self.all_running():
            return "STOPPED"
        if risk >= self.model_settings.warning_threshold:
            return "WARNING"
        return "RUNNING"

    def _maybe_create_stop(self, risk: float, action_taken: bool) -> bool:
        if action_taken or not self.all_running():
            return False

        s = self.state
        weakest = min(self.stages, key=lambda stage: stage.health)
        candidates: list[tuple[MachineStage, str]] = []

        for stage in self.stages:
            if stage.next_failure_in <= 0:
                if stage.health < 58.0 or risk > self.model_settings.warning_threshold:
                    candidates.append((stage, "Slitage passerade simulerad felgräns"))
                else:
                    stage.health = clamp(stage.health - random.uniform(8, 16), 0, 100)
                    stage.next_failure_in = exponential_minutes(stage.mtbf_minutes)
                    stage.last_issue = "Förhöjt slitage upptäckt"
                    self.record_event("WARN", stage.name, "Förhöjt slitage upptäcktes innan stopp")

        oven_gap = max(abs(zone - setpoint) for zone, setpoint in zip(s.oven_zones, self.oven.zone_setpoints))
        if s.film_left < 120 and risk > self.model_settings.warning_threshold:
            candidates.append((self._stage("Påspackare"), "Filmrullen tog slut under körning"))
        if oven_gap > self.oven.stop_tolerance and risk > self.model_settings.warning_threshold:
            candidates.append((self._stage("Ugn"), "Ugnszon hamnade utanför stoppgräns"))
        if s.quality_score < 64 and risk > self.model_settings.warning_threshold:
            candidates.append((self._stage("Mixer"), "Kvaliteten föll utanför processfönster"))

        random_stop_probability = clamp((risk - 0.72) * 0.22, 0.0, 0.08)
        if risk > self.model_settings.stop_threshold and random.random() < random_stop_probability:
            candidates.append((weakest, "Riskmodellen varnade men stopp uppstod ändå"))

        if not candidates:
            return False

        stage, reason = random.choice(candidates)
        stage.running = False
        stage.downtime_left = max(4, random.expovariate(1.0 / stage.mttr_minutes))
        stage.health = clamp(stage.health - random.uniform(12, 28), 0, 100)
        stage.last_issue = reason
        stage.next_failure_in = exponential_minutes(stage.mtbf_minutes)
        s.unplanned_stops += 1
        self.record_event("STOP", stage.name, reason)
        return True

    def _produce_if_possible(self, risk: float) -> None:
        s = self.state
        if not self.all_running():
            s.packs_last_minute = 0
            return

        speed_factor = s.belt_speed / self.production.default_belt_speed
        efficiency_curve = 1.0 + (speed_factor - 1.0) * 0.88
        risk_penalty = clamp(risk * 0.12, 0.0, 0.10)
        quality_yield = 1.0 - clamp((92.0 - s.quality_score) / 100.0, 0.0, 0.22)
        packs_float = self.production.baseline_packs_per_minute * efficiency_curve * (1.0 - risk_penalty) * quality_yield
        packs = max(0, rounded_int(packs_float + random.uniform(-0.4, 0.7)))
        waste = max(0, rounded_int(packs * clamp((92.0 - s.quality_score) / 100.0, 0.0, 0.18)))
        good_packs = max(0, packs - waste)
        s.waste_packs += waste
        s.packs_last_minute = good_packs

        if s.sku == "6 pack":
            s.packs_six += good_packs
            carton_size = self.production.packs_per_carton_six_pack
        else:
            s.packs_twelve += good_packs
            carton_size = self.production.packs_per_carton_twelve_pack

        s.film_left = max(0, s.film_left - int(good_packs * (1.0 if s.sku == "6 pack" else 1.35)))
        cartons = good_packs // carton_size
        self._add_cartons_to_pallet(cartons)

    def _add_cartons_to_pallet(self, cartons: int) -> None:
        s = self.state
        for _ in range(cartons):
            s.pallet_cartons += 1
            if s.pallet_cartons >= self.production.cartons_per_pallet_layer:
                s.pallet_cartons = 0
                s.pallet_layers += 1
            if s.pallet_layers >= self.production.layers_per_pallet:
                s.pallet_layers = 0
                s.pallets_done += 1
                self.record_event("PALLET", "Pall", "En pall färdigställdes")

    def _update_label_and_model(self, features: list[float], risk: float, stop_happened: bool) -> None:
        s = self.state
        strong_warning = risk > self.model_settings.stop_threshold
        bad_quality = s.quality_score < 70
        weak_machine = min(stage.health for stage in self.stages) < 45
        label = int(stop_happened or strong_warning or bad_quality or weak_machine)
        self.model.update(features, label)
        self.storage.save_training_sample(s.minute, label, risk, features)

    def _telemetry_row(self) -> dict:
        s = self.state
        packs_per_hour = self.current_packs_per_hour()
        availability = 100.0 - safe_percent(s.downtime_minutes, max(1, s.minute))
        performance = clamp(safe_percent(packs_per_hour, self.production.baseline_packs_per_hour), 0.0, 140.0)
        quality = s.quality_score
        oee = availability / 100.0 * performance / 100.0 * quality
        return {
            "minute": s.minute,
            "sku": s.sku,
            "line_state": s.line_status,
            "ai_active": int(s.ai_active),
            "speed_change_percent": round(self.speed_change_percent(), 2),
            "packs_total": s.packs_total,
            "packs_six": s.packs_six,
            "packs_twelve": s.packs_twelve,
            "packs_per_hour": round(packs_per_hour, 2),
            "baseline_packs_per_hour": round(self.production.baseline_packs_per_hour, 2),
            "throughput_lift_percent": round(self.throughput_lift_percent(), 2),
            "oee": round(oee, 2),
            "quality_score": round(s.quality_score, 2),
            "risk_probability": round(s.risk_probability, 5),
            "downtime_minutes": s.downtime_minutes,
            "prevented_stops": s.prevented_stops,
            "waste_packs": s.waste_packs,
            "pallets_done": s.pallets_done,
            "belt_speed": round(s.belt_speed, 3),
            "flow_kg_minute": round(s.flow_kg_minute, 3),
            "humidity": round(s.humidity, 3),
            "dough_temp": round(s.dough_temp, 3),
            "line_pressure": round(s.line_pressure, 3),
            "oven_z1": round(s.oven_zones[0], 3),
            "oven_z2": round(s.oven_zones[1], 3),
            "oven_z3": round(s.oven_zones[2], 3),
            "film_left": s.film_left,
            "energy_kwh": round(s.energy_kwh, 3),
            "net_value": 0.0,
        }

    def _stabilize_oven(self) -> None:
        for index, setpoint in enumerate(self.oven.zone_setpoints):
            self.state.oven_zones[index] = ease_towards(self.state.oven_zones[index], setpoint, self.oven.correction_gain)

    def _stage(self, name: str) -> MachineStage:
        for stage in self.stages:
            if stage.name == name:
                return stage
        raise ValueError(f"Unknown stage: {name}")

    def record_event(self, event_type: str, machine: str, message: str) -> None:
        event = {
            "minute": self.state.minute,
            "type": event_type,
            "machine": machine,
            "message": message,
            "risk_probability": round(self.state.risk_probability, 5),
            "ai_active": self.state.ai_active,
        }
        self.events.append(event)
        self.events = self.events[-120:]
        self.last_help_message = message if event_type in {"CONTROL", "PREVENTED", "STOP", "TEST"} else self.last_help_message
        self.storage.save_event(event)
