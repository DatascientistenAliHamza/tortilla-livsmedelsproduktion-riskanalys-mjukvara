# Projektrapport

## Sammanfattning

Tortilla Production Simulator är en simulerad produktionsdashboard för tortillaproduktion. Projektet kombinerar realtidssimulering, sparad data, maskininlärning och ekonomi för att visa hur ett produktionssystem kan gå från enkel övervakning till aktivt beslutsstöd.

Den senaste versionen har gjorts mer visuellt tydlig med ljus design, header med vyval, klickbara kontroller, informationssymboler och separata vyer för produktion, AI, ekonomi och logg.

## Problemformulering

Ett vanligt problem i produktion är att stopp upptäcks för sent. När linjen redan står still påverkas leverans, bemanning, kvalitet och kostnad. Ett datadrivet system bör därför inte bara visa vad som händer, utan även hjälpa användaren att förstå risker i tid.

Projektet är byggt kring frågan: hur kan en datascientist visa värde för en produktionsmiljö utan att ha tillgång till verklig fabriksdata?

Lösningen är att skapa en trovärdig simulering som genererar data, tränar en modell och visualiserar beslutsstöd på ett sätt som är lätt att förstå.

## Designbeslut

Dashboarden är uppdelad i fem vyer.

1. Översikt för ledning och snabb status.

2. Produktion för operatörer och produktionstekniker.

3. AI för att visa modellstatus, risk och riskdrivare.

4. Ekonomi för att översätta produktion och stopp till pengar.

5. Logg för spårbarhet och analys efter körning.

Detta gör att projektet inte känns som ett tekniskt experiment, utan som ett system flera roller kan använda.

## Simulerad data

Simuleringen skapar minutdata för hela linjen. Exempel på signaler är:

1. Bandhastighet.

2. Flöde i kilo per minut.

3. Luftfuktighet.

4. Degtemperatur.

5. Ugnstemperatur i tre zoner.

6. Linjetryck.

7. Filmnivå.

8. Kvalitetspoäng.

9. Maskinhälsa per station.

10. Energiförbrukning.

Dessa signaler används både för visualisering, riskmodellering och ekonomi.

## Maskininlärning

Modellen är byggd som en online modell. Den uppdateras löpande medan simuleringen körs. I början används en transparent heuristik så att systemet kan ge riskbedömningar direkt. När tillräckligt mycket träningsdata har samlats in börjar en SGD modell väga in historiska mönster.

Detta är ett medvetet val. I en portfolio demonstration är det viktigare att visa ett förståeligt system än att gömma allt bakom en svart låda.

## AI Aktiv och Inaktiv

AI läget är centralt i projektet.

När AI är Aktiv kan systemet utföra åtgärder automatiskt när risken blir hög. När AI är Inaktiv fortsätter riskbedömningen, men systemet agerar inte själv.

Detta gör det enkelt att förklara skillnaden mellan övervakning och beslutsstöd.

## Ekonomi

Ekonomivyn gör projektet mer affärsnära. Den visar hur förändrad hastighet, extra volym, undvikna stopp, svinn och energi påverkar en simulerad nettoeffekt.

Det är viktigt eftersom produktionsförbättringar sällan bara handlar om teknik. De måste också kunna förklaras i termer av kapacitet, kostnad och värde.

## Varför projektet är starkt på GitHub

Projektet visar flera kompetenser samtidigt.

1. Data science med löpande modellträning.

2. Simulering av ett verklighetsnära produktionsflöde.

3. Dashboard design med användarinteraktion.

4. Datainsamling och lagring för vidare analys.

5. Ekonomisk tolkning av tekniska beslut.

6. Kodstruktur med tydliga ansvarsområden.

Det gör projektet mer intressant än en statisk notebook, eftersom det visar tänkande från data till beslut.

## Möjliga nästa steg

1. Skapa en analys notebook som läser från SQLite databasen.

2. Lägg till export av automatiska rapporter per skift.

3. Bygg en Streamlit version för webben.

4. Lägg till fler scenarier för olika produktionsstrategier.

5. Jämför AI Aktiv mot AI Inaktiv över flera simulerade skift.
