from __future__ import annotations

import sys
import time
from dataclasses import dataclass, replace
from typing import Callable

import pygame
from pygame import Rect

from settings import AppSettings, EconomySettings, ProductionSettings
from simulation import TortillaFactorySimulation
from utils import clamp, format_currency, safe_percent


@dataclass
class Button:
    label: str
    rect: Rect
    action: Callable[[], None]
    hotkey: str
    info: str
    accent: tuple[int, int, int] | None = None

    @property
    def info_rect(self) -> Rect:
        return Rect(self.rect.right - 30, self.rect.y + 8, 20, 20)


@dataclass
class Tab:
    label: str
    view: str
    rect: Rect
    info: str


class DashboardApp:
    """Clickable Pygame dashboard for the tortilla production simulation."""

    def __init__(self) -> None:
        pygame.init()
        self.settings = AppSettings()
        pygame.display.set_caption(self.settings.title)
        self.screen = pygame.display.set_mode((self.settings.width, self.settings.height), pygame.RESIZABLE)
        self._try_maximize_window()
        self.settings = replace(self.settings, width=self.screen.get_width(), height=self.screen.get_height())
        self.clock = pygame.time.Clock()
        self.simulation = TortillaFactorySimulation()
        self.production = ProductionSettings()
        self.economy = EconomySettings()
        self.running = True
        self.paused = False
        self.fast_mode = False
        self.current_view = "overview"
        self.last_tick = time.time()
        self.mouse_position = (0, 0)
        self.active_hint = "Klicka på informationssymbolen vid en knapp för att se vad den gör."

        display_faces = ["Orbitron", "Rajdhani", "Bahnschrift", "Agency FB", "Consolas", "Segoe UI"]
        ui_faces = ["Bahnschrift", "Rajdhani", "Segoe UI Variable Text", "Segoe UI", "Arial"]
        self.fonts = {
            "hero": self._font(display_faces, 38, bold=True),
            "title": self._font(display_faces, 25, bold=True),
            "section": self._font(display_faces, 19, bold=True),
            "body": self._font(ui_faces, 16),
            "small": self._font(ui_faces, 13),
            "tiny": self._font(ui_faces, 11),
            "kpi": self._font(display_faces, 30, bold=True),
            "tab": self._font(display_faces, 15, bold=True),
        }
        self.colors = {
            "background": (7, 12, 23),
            "surface": (13, 20, 34),
            "surface_soft": (22, 33, 52),
            "surface_blue": (18, 47, 74),
            "text": (231, 241, 255),
            "muted": (136, 158, 184),
            "line": (42, 60, 85),
            "green": (39, 233, 161),
            "green_soft": (15, 71, 55),
            "yellow": (255, 190, 72),
            "yellow_soft": (82, 58, 22),
            "red": (255, 92, 119),
            "red_soft": (80, 29, 42),
            "blue": (61, 174, 255),
            "blue_soft": (17, 54, 88),
            "purple": (174, 119, 255),
            "purple_soft": (54, 36, 86),
            "dark": (3, 8, 16),
            "button": (17, 27, 45),
            "button_hover": (27, 44, 72),
        }
        self.tabs = self._build_tabs()
        self.buttons = self._build_buttons()

    def _font(self, names: list[str], size: int, bold: bool = False) -> pygame.font.Font:
        for name in names:
            path = pygame.font.match_font(name, bold=bold)
            if path:
                return pygame.font.Font(path, size)
        return pygame.font.SysFont("segoeui", size, bold=bold)

    def _try_maximize_window(self) -> None:
        try:
            from pygame._sdl2 import Window

            Window.from_display_module().maximize()
            self.screen = pygame.display.get_surface() or self.screen
        except Exception:
            # Pygame/SDL does not expose maximize on every system. The app still opens resizable.
            pass

    def _resize_window(self, width: int, height: int) -> None:
        width = max(1400, int(width))
        height = max(900, int(height))
        self.screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)
        self.settings = replace(self.settings, width=width, height=height)
        self.tabs = self._build_tabs()
        self.buttons = self._build_buttons()

    def _build_tabs(self) -> list[Tab]:
        labels = [
            ("Översikt", "overview", "Samlad ledningsvy med risk, OEE, produktion och rekommendation."),
            ("Produktion", "production", "Operatörsvy för takt, linjestatus, flaskhalsar och processdata."),
            ("AI", "ai", "Visar om AI är aktiv, hur modellen tränas och vilka riskdrivare som påverkar beslutet."),
            ("Ekonomi", "economy", "Översätter fart, stopp, svinn och prevention till pengar och procent."),
            ("Logg", "logs", "Händelser som sparas till JSONL och SQLite under körning."),
        ]
        tabs: list[Tab] = []
        x = 30
        for label, view, info in labels:
            rect = Rect(x, 80, 132, 36)
            tabs.append(Tab(label, view, rect, info))
            x += 142
        return tabs

    def _build_buttons(self) -> list[Button]:
        top = self.settings.height - 82
        left = 30
        gap = 10
        width = max(148, int((self.settings.width - 60 - gap * 7) / 8))
        s = self.simulation.state
        ai_label = "AI Aktiv" if s.ai_active else "AI Inaktiv"
        ai_accent = self.colors["green"] if s.ai_active else self.colors["red"]
        specs = [
            ("Paus" if not self.paused else "Starta", self.toggle_pause, "Space", "Pausar eller startar simuleringen utan att nollställa data.", self.colors["yellow"]),
            ("Demo x3" if not self.fast_mode else "Normal takt", self.toggle_fast, "F", "Växlar mellan lugn normal takt och en tydligare demo-takt. Normal takt är avsiktligt långsammare så man hinner se vad som händer.", self.colors["purple"]),
            (ai_label, self.simulation.toggle_ai, "A", "Slår AI prevention av eller på. När AI är aktiv kan systemet själv förebygga stopp.", ai_accent),
            ("Fart −5%", lambda: self.simulation.adjust_speed_percent(-5), "S", "Sänker bandhastigheten fem procent mot nuvarande läge och visar effekten i KPI.", self.colors["blue"]),
            ("Fart +5%", lambda: self.simulation.adjust_speed_percent(5), "W", "Ökar bandhastigheten fem procent mot nuvarande läge och visar effekt på produktion och ekonomi.", self.colors["blue"]),
            ("Förebygg nu", lambda: self.simulation.apply_preventive_action(source="Operator"), "P", "Kör en manuell åtgärd som mikroservice, filmbyte eller processjustering.", self.colors["green"]),
            ("Injicera fel", self.simulation.inject_fault, "I", "Skapar ett kontrollerat fel så att riskmodellen och logiken kan demonstreras.", self.colors["red"]),
            ("Reset", self.simulation.reset, "R", "Startar om simuleringen och skapar ny data från början.", self.colors["dark"]),
        ]
        buttons: list[Button] = []
        for index, (label, action, hotkey, info, accent) in enumerate(specs):
            buttons.append(Button(label, Rect(left + index * (width + gap), top, width, 54), action, hotkey, info, accent))
        return buttons

    def run(self) -> None:
        while self.running:
            self.buttons = self._build_buttons()
            self.handle_events()
            self.tick_if_needed()
            self.draw()
            self.clock.tick(self.settings.fps)
        self.simulation.storage.close()
        pygame.quit()
        sys.exit(0)

    def handle_events(self) -> None:
        self.mouse_position = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.VIDEORESIZE:
                self._resize_window(event.w, event.h)
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self._handle_mouse_click(event.pos)
            elif event.type == pygame.KEYDOWN:
                self._handle_key(event.key)

    def _handle_mouse_click(self, position: tuple[int, int]) -> None:
        for tab in self.tabs:
            if tab.rect.collidepoint(position):
                self.current_view = tab.view
                self.active_hint = tab.info
                return
        for button in self.buttons:
            if button.info_rect.collidepoint(position):
                self.active_hint = button.info
                return
            if button.rect.collidepoint(position):
                button.action()
                self.active_hint = button.info
                return

    def _handle_key(self, key: int) -> None:
        if key in (pygame.K_ESCAPE, pygame.K_q):
            self.running = False
        elif key == pygame.K_SPACE:
            self.toggle_pause()
        elif key == pygame.K_f:
            self.toggle_fast()
        elif key == pygame.K_a:
            self.simulation.toggle_ai()
        elif key == pygame.K_w:
            self.simulation.adjust_speed_percent(5)
        elif key == pygame.K_s:
            self.simulation.adjust_speed_percent(-5)
        elif key == pygame.K_p:
            self.simulation.apply_preventive_action(source="Operator")
        elif key == pygame.K_i:
            self.simulation.inject_fault()
        elif key == pygame.K_r:
            self.simulation.reset()
        elif key == pygame.K_1:
            self.current_view = "overview"
        elif key == pygame.K_2:
            self.current_view = "production"
        elif key == pygame.K_3:
            self.current_view = "ai"
        elif key == pygame.K_4:
            self.current_view = "economy"
        elif key == pygame.K_5:
            self.current_view = "logs"

    def toggle_pause(self) -> None:
        self.paused = not self.paused
        state = "pausad" if self.paused else "startad"
        self.simulation.record_event("CONTROL", "Operator", f"Simuleringen är {state}")

    def toggle_fast(self) -> None:
        self.fast_mode = not self.fast_mode
        state = "aktiv" if self.fast_mode else "inaktiv"
        self.simulation.record_event("CONTROL", "Operator", f"Demo x3 är {state}")

    def tick_if_needed(self) -> None:
        if self.paused:
            return
        interval = self.settings.seconds_per_sim_minute
        if self.fast_mode:
            interval /= self.settings.fast_multiplier
        now = time.time()
        if now - self.last_tick >= interval:
            self.last_tick = now
            self.simulation.tick()

    def draw(self) -> None:
        self.screen.fill(self.colors["background"])
        self.draw_background_grid()
        self.draw_header()
        if self.current_view == "overview":
            self.draw_overview_view()
        elif self.current_view == "production":
            self.draw_production_view()
        elif self.current_view == "ai":
            self.draw_ai_view()
        elif self.current_view == "economy":
            self.draw_economy_view()
        else:
            self.draw_log_view()
        self.draw_bottom_controls()
        pygame.display.flip()

    def draw_background_grid(self) -> None:
        w, h = self.settings.width, self.settings.height
        grid_color = (18, 31, 50)
        for x in range(0, w, 64):
            pygame.draw.line(self.screen, grid_color, (x, 0), (x, h), 1)
        for y in range(0, h, 64):
            pygame.draw.line(self.screen, grid_color, (0, y), (w, y), 1)
        pygame.draw.line(self.screen, self.colors["blue"], (0, 132), (w, 132), 1)

    def draw_header(self) -> None:
        s = self.simulation.state
        w = self.settings.width
        self.round_rect(Rect(0, 0, w, 132), self.colors["surface"], 0)
        pygame.draw.line(self.screen, self.colors["line"], (0, 131), (w, 131), 1)
        pygame.draw.line(self.screen, self.colors["blue"], (30, 66), (520, 66), 2)
        self.text(self.settings.title.upper(), 30, 22, "hero", self.colors["text"])
        self.draw_tabs()

        live_label = "PAUS" if self.paused else "LIVE"
        live_color = self.colors["yellow"] if self.paused else self.colors["green"]
        ai_label = "AI AKTIV" if s.ai_active else "AI INAKTIV"
        ai_color = self.colors["green"] if s.ai_active else self.colors["red"]
        right = w - 30
        self.pill(ai_label, right - 112, 24, 112, 30, ai_color, self.colors["dark"])
        self.pill("DEMO x3" if self.fast_mode else "NORMAL", right - 224, 24, 102, 30, self.colors["purple"], self.colors["dark"])
        self.pill(live_label, right - 318, 24, 84, 30, live_color, self.colors["dark"])
        self.text(f"Minut {s.minute}", right - 318, 62, "small", self.colors["muted"])
        self.text(f"SKU {s.sku}", right - 224, 62, "small", self.colors["muted"])
        self.text(f"Fart {self.simulation.speed_change_percent():+.0f}%", right - 112, 62, "small", self.colors["muted"])
        self.draw_event_ticker(Rect(790, 82, max(360, w - 820), 34))

    def draw_event_ticker(self, rect: Rect) -> None:
        if rect.width <= 0:
            return
        event = self.simulation.events[-1] if self.simulation.events else None
        if event:
            message = f"SENASTE HÄNDELSE  •  min {event['minute']}  •  {event['machine']}  •  {event['message']}"
            color = self.event_color(event["type"])
        else:
            message = "SENASTE HÄNDELSE  •  simuleringen startar"
            color = self.colors["blue"]
        self.round_rect(rect, self.colors["surface_soft"], 15)
        pygame.draw.circle(self.screen, color, (rect.x + 18, rect.y + rect.height // 2), 5)
        max_width = rect.width - 44
        while self.fonts["small"].size(message)[0] > max_width and len(message) > 12:
            message = message[:-2].rstrip() + "…"
        self.text(message, rect.x + 32, rect.y + 9, "small", self.colors["text"])

    def draw_tabs(self) -> None:
        for index, tab in enumerate(self.tabs, start=1):
            active = tab.view == self.current_view
            color = self.colors["blue"] if active else self.colors["surface_soft"]
            text_color = self.colors["dark"] if active else self.colors["muted"]
            self.round_rect(tab.rect, color, 18)
            self.text(f"{index}  {tab.label}", tab.rect.x + 16, tab.rect.y + 9, "tab", text_color)

    def draw_overview_view(self) -> None:
        self.draw_kpi_row(144)
        self.draw_line_map(Rect(30, 286, 1060, 196), compact=True)
        self.panel(1110, 286, 360, 196, "Beslutsstöd")
        recommendation = self.simulation.model.recommendation(self.simulation.model.last_features, self.simulation.state.ai_active)
        self.wrapped_text(recommendation, 1132, 330, 320, "body", self.colors["text"], line_height=22)
        self.text("Aktuell signal", 1132, 410, "small", self.colors["muted"])
        self.text(self._status_sentence(), 1132, 432, "body", self.status_color())

        self.panel(30, 504, 700, 284, "Risk och produktion")
        self.draw_series([row["risk_probability"] * 100 for row in self.simulation.history[-120:]], Rect(60, 556, 630, 82), self.colors["red"], "Risk för stopp procent", 0, 100)
        self.draw_series([row["packs_per_hour"] for row in self.simulation.history[-120:]], Rect(60, 682, 630, 72), self.colors["green"], "Paket per timme")

        self.panel(755, 504, 715, 284, "Processfönster")
        self.draw_series([row["quality_score"] for row in self.simulation.history[-120:]], Rect(790, 556, 640, 70), self.colors["blue"], "Kvalitet", 50, 100)
        self.draw_series([row["line_pressure"] for row in self.simulation.history[-120:]], Rect(790, 660, 640, 70), self.colors["purple"], "Linjetryck", 25, 100)
        self.draw_hint_card(1132, 736, 314)

    def draw_production_view(self) -> None:
        self.panel(30, 144, 1040, 298, "Produktion och linjestatus")
        self.draw_line_map(Rect(54, 190, 990, 205), compact=False)
        self.draw_speed_card(1090, 144, 380, 298)

        self.panel(30, 464, 700, 324, "Takt mot standard")
        baseline = self.production.baseline_packs_per_hour
        current = self.simulation.current_packs_per_hour()
        self.draw_comparison_bars(70, 535, 600, baseline, current, "Standard", "Nu")
        self.text(f"Standard: {baseline:.0f} paket per timme", 70, 680, "body", self.colors["muted"])
        self.text(f"Nuvarande: {current:.0f} paket per timme", 70, 706, "body", self.colors["text"])
        self.text(f"Skillnad: {self.simulation.throughput_lift_percent():+.1f} procent", 70, 732, "body", self.lift_color(self.simulation.throughput_lift_percent()))

        self.panel(755, 464, 715, 324, "Processdetaljer")
        self.draw_series([row["oven_z1"] for row in self.simulation.history[-120:]], Rect(790, 520, 640, 56), self.colors["yellow"], "Ugn zon 1")
        self.draw_series([row["oven_z2"] for row in self.simulation.history[-120:]], Rect(790, 600, 640, 56), self.colors["blue"], "Ugn zon 2")
        self.draw_series([row["belt_speed"] for row in self.simulation.history[-120:]], Rect(790, 680, 640, 56), self.colors["purple"], "Bandhastighet")

    def draw_ai_view(self) -> None:
        s = self.simulation.state
        self.panel(30, 144, 450, 260, "AI status")
        status = "Aktiv" if s.ai_active else "Inaktiv"
        color = self.colors["green"] if s.ai_active else self.colors["red"]
        self.text(status, 60, 196, "kpi", color)
        self.text("AI prevention kan själv utföra förebyggande åtgärder när risken blir hög.", 60, 240, "body", self.colors["muted"])
        self.text(f"Modelltränad: {self.simulation.model.readiness_percent:.0f}%", 60, 286, "body", self.colors["text"])
        self.progress_bar(60, 318, 360, 12, self.simulation.model.readiness_percent / 100, self.colors["blue"])
        self.text(f"Träningspunkter: {self.simulation.model.samples_seen}", 60, 346, "small", self.colors["muted"])

        self.panel(505, 144, 470, 260, "Riskbeslut")
        risk = s.risk_probability * 100
        self.text(f"{risk:.0f}%", 535, 194, "kpi", self.risk_color(risk))
        self.text("Aktuell risk för stopp", 535, 236, "body", self.colors["muted"])
        self.text(f"Heuristik {self.simulation.model.last_heuristic * 100:.0f}%", 535, 284, "body", self.colors["text"])
        self.text(f"Online modell {self.simulation.model.last_model_risk * 100:.0f}%", 535, 312, "body", self.colors["text"])
        self.text("Modellen kombinerar regelbaserad risk med online inlärning.", 535, 350, "small", self.colors["muted"])

        self.panel(1000, 144, 470, 260, "AI rekommendation")
        recommendation = self.simulation.model.recommendation(self.simulation.model.last_features, s.ai_active)
        self.wrapped_text(recommendation, 1030, 196, 400, "body", self.colors["text"], 24)
        self.text("När AI är inaktiv loggas risker, men systemet gör inte automatiska åtgärder.", 1030, 318, "small", self.colors["muted"])

        self.panel(30, 430, 700, 358, "Viktigaste riskdrivare")
        drivers = self.simulation.model.risk_drivers(self.simulation.model.last_features)
        y = 488
        for label, score, description in drivers:
            self.text(label, 60, y, "body", self.colors["text"])
            self.progress_bar(190, y + 5, 360, 12, score, self.driver_color(score))
            self.text(f"{score * 100:.0f}%", 570, y - 1, "body", self.driver_color(score))
            self.text(description, 60, y + 27, "small", self.colors["muted"])
            y += 68

        self.panel(755, 430, 715, 358, "AI lärande över tid")
        self.draw_series([row["risk_probability"] * 100 for row in self.simulation.history[-160:]], Rect(790, 490, 640, 72), self.colors["red"], "Risk", 0, 100)
        self.draw_series([row["prevented_stops"] for row in self.simulation.history[-160:]], Rect(790, 612, 640, 72), self.colors["green"], "Förebyggda stopp")
        self.draw_hint_card(790, 716, 640)

    def draw_economy_view(self) -> None:
        economy = self.simulation.economy_snapshot()
        self.draw_economy_kpis(economy)
        self.panel(30, 304, 700, 484, "Ekonomisk jämförelse")
        self.draw_economy_waterfall(70, 372, 610, economy)
        self.panel(755, 304, 715, 484, "För chefer och ekonomer")
        speed = self.simulation.speed_change_percent()
        lift = self.simulation.throughput_lift_percent()
        self.text("Tolkning", 790, 356, "section", self.colors["text"])
        lines = [
            f"Standardläge betyder {self.production.baseline_packs_per_hour:.0f} paket per timme vid normal takt.",
            f"Nu kör linjen {speed:+.0f} procent i fart och producerar cirka {lift:+.1f} procent mot standard.",
            f"Extra volym jämförs mot hur många paket standardläget hade hunnit producera efter {self.simulation.state.minute} minuter.",
            "Förebyggda stopp räknas som undviken stilleståndstid multiplicerad med uppskattad stoppkostnad per minut.",
            "Nettoeffekten visar extra marginal plus undviken stoppkostnad minus svinn och energi.",
        ]
        y = 396
        for line in lines:
            self.wrapped_text(line, 790, y, 630, "body", self.colors["muted"], 22)
            y += 54
        self.text("Scenario", 790, 684, "section", self.colors["text"])
        scenario_value = self.estimate_speed_scenario_value(5)
        self.text(f"Om hastigheten ökas 5 procent från standard och kvaliteten hålls stabil kan nettovärdet bli ungefär {format_currency(scenario_value)} per skift.", 790, 724, "body", self.colors["text"])

    def draw_log_view(self) -> None:
        self.panel(30, 144, 940, 644, "Händelselogg")
        events = list(reversed(self.simulation.events[-14:]))
        y = 200
        for event in events:
            color = self.event_color(event["type"])
            self.text(event["type"], 60, y, "body", color)
            self.text(f"minut {event['minute']}  {event['machine']}", 180, y, "body", self.colors["muted"])
            self.wrapped_text(event["message"], 60, y + 26, 840, "small", self.colors["text"], 18)
            pygame.draw.line(self.screen, self.colors["line"], (60, y + 58), (920, y + 58), 1)
            y += 70
        self.panel(1000, 144, 470, 644, "Data som sparas")
        rows = [
            ("SQLite", "out/tortilla_factory.db"),
            ("Telemetri", "out/telemetry_stream.csv"),
            ("Träning", "out/training_samples.csv"),
            ("Ekonomi", "out/economy_snapshots.csv"),
            ("Händelser", "out/events.jsonl"),
        ]
        y = 205
        for title, path in rows:
            self.text(title, 1030, y, "body", self.colors["text"])
            self.text(path, 1030, y + 25, "small", self.colors["muted"])
            y += 76
        self.draw_hint_card(1030, 640, 395)

    def draw_kpi_row(self, y: int) -> None:
        s = self.simulation.state
        economy = self.simulation.economy_snapshot()
        target_progress = safe_percent(s.packs_total, self.production.target_packs_per_shift)
        risk = s.risk_probability * 100
        uptime = 100 - safe_percent(s.downtime_minutes, max(1, s.minute))
        kpis = [
            ("Risk för stopp", f"{risk:.0f}%", self.risk_color(risk), "AI bedömning just nu"),
            ("OEE", f"{self.latest_value('oee'):.0f}%", self.oee_color(self.latest_value('oee')), "Tillgänglighet kvalitet takt"),
            ("Produktion", f"{self.simulation.current_packs_per_hour():.0f}/h", self.colors["blue"], f"{self.simulation.throughput_lift_percent():+.1f}% mot standard"),
            ("Skiftmål", f"{target_progress:.0f}%", self.colors["purple"], f"{s.packs_total} av {self.production.target_packs_per_shift}"),
            ("Förebyggda stopp", str(s.prevented_stops), self.colors["green"], f"{s.avoided_downtime_minutes} min undvikna"),
            ("Nettoeffekt", format_currency(economy["net_value"]), self.money_color(economy["net_value"]), "Extra värde i simuleringen"),
        ]
        x = 30
        for title, value, color, note in kpis:
            self.card(x, y, 225, 112)
            self.text(title, x + 16, y + 16, "small", self.colors["muted"])
            self.text(value, x + 16, y + 43, "kpi", color)
            self.text(note, x + 16, y + 82, "small", self.colors["muted"])
            x += 240

    def draw_line_map(self, rect: Rect, compact: bool) -> None:
        stages = self.simulation.stages
        self.text("Produktionslinje", rect.x, rect.y - 30, "section", self.colors["text"])
        pygame.draw.line(self.screen, self.colors["line"], (rect.x + 20, rect.y + 91), (rect.right - 20, rect.y + 91), 4)
        gap = 10 if compact else 11
        stage_width = int((rect.width - gap * (len(stages) - 1)) / len(stages))
        for index, stage in enumerate(stages):
            x = rect.x + index * (stage_width + gap)
            color = self.health_color(stage.health, stage.running)
            y = rect.y + 34
            h = 104 if compact else 128
            self.round_rect(Rect(x, y, stage_width, h), self.colors["surface"], 18)
            self.round_rect(Rect(x, y, stage_width, h), color, 18, width=2)
            self.text(stage.name, x + 10, y + 12, "small", self.colors["text"])
            status = "I drift" if stage.running else "Stopp"
            self.text(status, x + 10, y + 36, "small", color)
            self.progress_bar(x + 10, y + 66, stage_width - 20, 10, stage.health / 100, color)
            self.text(f"{stage.health:.0f}%", x + 10, y + 82, "tiny", self.colors["muted"])
            if not compact:
                self.wrapped_text(stage.operator_note, x + 10, y + 100, stage_width - 18, "tiny", self.colors["muted"], 13)
            if index < len(stages) - 1:
                pygame.draw.circle(self.screen, self.colors["blue"], (x + stage_width + gap // 2, rect.y + 91), 4)
        pallet_progress = self.simulation.state.pallet_layers * self.production.cartons_per_pallet_layer + self.simulation.state.pallet_cartons
        pallet_total = self.production.layers_per_pallet * self.production.cartons_per_pallet_layer
        self.progress_bar(rect.x + 20, rect.bottom - 24, rect.width - 40, 10, pallet_progress / pallet_total, self.colors["purple"])
        self.text(f"Pallstatus {pallet_progress} av {pallet_total} positioner, färdiga pallar {self.simulation.state.pallets_done}", rect.x + 20, rect.bottom - 54, "small", self.colors["muted"])

    def draw_speed_card(self, x: int, y: int, width: int, height: int) -> None:
        self.panel(x, y, width, height, "Taktstyrning")
        speed = self.simulation.speed_change_percent()
        lift = self.simulation.throughput_lift_percent()
        self.text(f"{speed:+.0f}%", x + 30, y + 58, "kpi", self.lift_color(speed))
        self.text("fart mot standard", x + 30, y + 98, "body", self.colors["muted"])
        self.progress_bar(x + 30, y + 142, width - 60, 14, (speed + 30) / 65, self.lift_color(speed))
        self.text("−30%", x + 30, y + 164, "small", self.colors["muted"])
        self.text("Standard", x + width // 2 - 32, y + 164, "small", self.colors["muted"])
        self.text("+35%", x + width - 70, y + 164, "small", self.colors["muted"])
        self.text(f"Produktionseffekt {lift:+.1f}%", x + 30, y + 212, "section", self.lift_color(lift))
        self.text("Ökad fart kan ge mer volym, men också mer risk, svinn och energikostnad.", x + 30, y + 244, "small", self.colors["muted"])

    def draw_economy_kpis(self, economy: dict[str, float]) -> None:
        values = [
            ("Extra paket", f"{economy['extra_packs']:+.0f}", self.lift_color(economy["extra_packs"]), "Mot standardläge"),
            ("Extra marginal", format_currency(economy["extra_margin"]), self.money_color(economy["extra_margin"]), "Volymens värde"),
            ("Undviken stoppkostnad", format_currency(economy["avoided_downtime_value"]), self.colors["green"], "AI prevention"),
            ("Svinnkostnad", format_currency(economy["waste_cost"]), self.colors["red"], "Kvalitetsförlust"),
            ("Energikostnad", format_currency(economy["energy_cost"]), self.colors["yellow"], "Simulerad energi"),
            ("Netto", format_currency(economy["net_value"]), self.money_color(economy["net_value"]), "Total effekt"),
        ]
        x = 30
        y = 144
        for title, value, color, note in values:
            self.card(x, y, 225, 112)
            self.text(title, x + 16, y + 16, "small", self.colors["muted"])
            self.text(value, x + 16, y + 43, "kpi", color)
            self.text(note, x + 16, y + 82, "small", self.colors["muted"])
            x += 240

    def draw_economy_waterfall(self, x: int, y: int, width: int, economy: dict[str, float]) -> None:
        items = [
            ("Extra marginal", economy["extra_margin"], self.colors["green"]),
            ("Undvikna stopp", economy["avoided_downtime_value"], self.colors["green"]),
            ("Svinn", -economy["waste_cost"], self.colors["red"]),
            ("Energi", -economy["energy_cost"], self.colors["yellow"]),
            ("Netto", economy["net_value"], self.money_color(economy["net_value"])),
        ]
        max_abs = max(1.0, max(abs(value) for _, value, _ in items))
        center = x + width // 2
        pygame.draw.line(self.screen, self.colors["line"], (center, y - 15), (center, y + 280), 1)
        current_y = y
        for label, value, color in items:
            bar_width = int(abs(value) / max_abs * (width * 0.42))
            if value >= 0:
                bar_rect = Rect(center, current_y, bar_width, 28)
            else:
                bar_rect = Rect(center - bar_width, current_y, bar_width, 28)
            self.round_rect(bar_rect, color, 8)
            self.text(label, x, current_y + 4, "body", self.colors["text"])
            self.text(format_currency(value), center + 12 if value >= 0 else center - bar_width - 100, current_y + 5, "small", color)
            current_y += 54
        self.text("Värdena bygger på simulerade antaganden och är till för att visa beslutslogiken.", x, y + 310, "small", self.colors["muted"])

    def draw_comparison_bars(self, x: int, y: int, width: int, baseline: float, current: float, baseline_label: str, current_label: str) -> None:
        max_value = max(baseline, current, 1)
        baseline_width = int(width * baseline / max_value)
        current_width = int(width * current / max_value)
        self.text(baseline_label, x, y, "body", self.colors["muted"])
        self.round_rect(Rect(x + 130, y + 2, baseline_width, 24), self.colors["surface_soft"], 10)
        self.text(f"{baseline:.0f}", x + 130 + baseline_width + 12, y + 4, "small", self.colors["muted"])
        self.text(current_label, x, y + 56, "body", self.colors["text"])
        self.round_rect(Rect(x + 130, y + 58, current_width, 24), self.colors["blue"], 10)
        self.text(f"{current:.0f}", x + 130 + current_width + 12, y + 60, "small", self.colors["blue"])

    def draw_bottom_controls(self) -> None:
        w = self.settings.width
        h = self.settings.height
        top = h - 110
        self.round_rect(Rect(0, top, w, 110), self.colors["surface"], 0)
        pygame.draw.line(self.screen, self.colors["line"], (0, top), (w, top), 1)
        self.text("Klickbara kontroller", 30, top + 10, "small", self.colors["muted"])
        for button in self.buttons:
            hovered = button.rect.collidepoint(self.mouse_position)
            color = self.colors["button_hover"] if hovered else self.colors["button"]
            self.round_rect(button.rect, color, 16)
            self.round_rect(button.rect, self.colors["line"], 16, width=1)
            if button.accent:
                pygame.draw.circle(self.screen, button.accent, (button.rect.x + 18, button.rect.y + 27), 5)
            self.text(button.label, button.rect.x + 32, button.rect.y + 13, "body", self.colors["text"])
            self.text(button.hotkey, button.rect.x + 32, button.rect.y + 36, "tiny", self.colors["muted"])
            info_color = self.colors["blue"] if button.info_rect.collidepoint(self.mouse_position) else self.colors["surface_soft"]
            self.round_rect(button.info_rect, info_color, 10)
            self.text("!", button.info_rect.x + 8, button.info_rect.y + 2, "tiny", self.colors["dark"] if info_color == self.colors["blue"] else self.colors["muted"])

    def draw_hint_card(self, x: int, y: int, width: int) -> None:
        self.round_rect(Rect(x, y, width, 48), self.colors["blue_soft"], 14)
        self.wrapped_text(self.active_hint, x + 14, y + 10, width - 24, "small", self.colors["blue"], 17)

    def draw_series(self, values: list[float], rect: Rect, color: tuple[int, int, int], label: str, fixed_min: float | None = None, fixed_max: float | None = None) -> None:
        self.text(label, rect.x, rect.y - 22, "small", self.colors["muted"])
        self.round_rect(rect, self.colors["surface_soft"], 12)
        if len(values) < 2:
            self.text("Samlar data", rect.x + 18, rect.y + rect.height // 2 - 8, "small", self.colors["muted"])
            return
        low = min(values) if fixed_min is None else fixed_min
        high = max(values) if fixed_max is None else fixed_max
        if abs(high - low) < 0.001:
            high = low + 1.0
        points = []
        for index, value in enumerate(values):
            x = rect.x + int(index * rect.width / (len(values) - 1))
            normalized = (value - low) / (high - low)
            y = rect.bottom - int(clamp(normalized, 0.0, 1.0) * rect.height)
            points.append((x, y))
        pygame.draw.lines(self.screen, color, False, points, 3)
        pygame.draw.circle(self.screen, color, points[-1], 5)
        self.text(f"{values[-1]:.1f}", rect.right - 62, rect.y + 8, "small", color)

    def panel(self, x: int, y: int, width: int, height: int, title: str) -> None:
        self.round_rect(Rect(x, y, width, height), self.colors["surface"], 20)
        self.round_rect(Rect(x, y, width, height), self.colors["line"], 20, width=1)
        self.text(title, x + 20, y + 18, "section", self.colors["text"])

    def card(self, x: int, y: int, width: int, height: int) -> None:
        self.round_rect(Rect(x, y, width, height), self.colors["surface"], 18)
        self.round_rect(Rect(x, y, width, height), self.colors["line"], 18, width=1)

    def progress_bar(self, x: int, y: int, width: int, height: int, progress: float, color: tuple[int, int, int]) -> None:
        self.round_rect(Rect(x, y, width, height), self.colors["surface_soft"], height // 2)
        fill = int(width * clamp(progress, 0.0, 1.0))
        if fill > 0:
            self.round_rect(Rect(x, y, fill, height), color, height // 2)

    def pill(self, label: str, x: int, y: int, width: int, height: int, color: tuple[int, int, int], text_color: tuple[int, int, int]) -> None:
        self.round_rect(Rect(x, y, width, height), color, height // 2)
        rendered = self.fonts["small"].render(label, True, text_color)
        self.screen.blit(rendered, (x + width // 2 - rendered.get_width() // 2, y + 8))

    def text(self, value: str, x: int, y: int, size: str = "body", color: tuple[int, int, int] | None = None) -> None:
        rendered = self.fonts[size].render(str(value), True, color or self.colors["text"])
        self.screen.blit(rendered, (x, y))

    def wrapped_text(self, value: str, x: int, y: int, width: int, size: str, color: tuple[int, int, int], line_height: int = 20) -> None:
        words = str(value).split()
        line = ""
        current_y = y
        for word in words:
            test = f"{line} {word}".strip()
            if self.fonts[size].size(test)[0] <= width:
                line = test
            else:
                self.text(line, x, current_y, size, color)
                current_y += line_height
                line = word
        if line:
            self.text(line, x, current_y, size, color)

    def round_rect(self, rect: Rect, color: tuple[int, int, int], radius: int, width: int = 0) -> None:
        pygame.draw.rect(self.screen, color, rect, width=width, border_radius=radius)

    def latest_value(self, key: str) -> float:
        if not self.simulation.history:
            if key == "oee":
                return 0.0
            return 0.0
        return float(self.simulation.history[-1].get(key, 0.0))

    def risk_color(self, risk_percent: float) -> tuple[int, int, int]:
        if risk_percent >= 70:
            return self.colors["red"]
        if risk_percent >= 45:
            return self.colors["yellow"]
        return self.colors["green"]

    def oee_color(self, value: float) -> tuple[int, int, int]:
        if value >= 75:
            return self.colors["green"]
        if value >= 55:
            return self.colors["yellow"]
        return self.colors["red"]

    def health_color(self, value: float, running: bool) -> tuple[int, int, int]:
        if not running:
            return self.colors["red"]
        if value >= 72:
            return self.colors["green"]
        if value >= 48:
            return self.colors["yellow"]
        return self.colors["red"]

    def driver_color(self, score: float) -> tuple[int, int, int]:
        if score >= 0.70:
            return self.colors["red"]
        if score >= 0.40:
            return self.colors["yellow"]
        return self.colors["green"]

    def lift_color(self, value: float) -> tuple[int, int, int]:
        if value > 0:
            return self.colors["green"]
        if value < 0:
            return self.colors["red"]
        return self.colors["muted"]

    def money_color(self, value: float) -> tuple[int, int, int]:
        if value >= 0:
            return self.colors["green"]
        return self.colors["red"]

    def event_color(self, event_type: str) -> tuple[int, int, int]:
        if event_type == "STOP":
            return self.colors["red"]
        if event_type == "PREVENTED":
            return self.colors["green"]
        if event_type in {"WARN", "TEST"}:
            return self.colors["yellow"]
        if event_type == "BATCH":
            return self.colors["purple"]
        return self.colors["blue"]

    def status_color(self) -> tuple[int, int, int]:
        state = self.simulation.state.line_status
        if state == "STOPPED":
            return self.colors["red"]
        if state == "WARNING":
            return self.colors["yellow"]
        return self.colors["green"]

    def _status_sentence(self) -> str:
        state = self.simulation.state.line_status
        if state == "STOPPED":
            return "Linjen står still och återstart pågår"
        if state == "WARNING":
            return "Risknivån är förhöjd, åtgärd rekommenderas"
        return "Linjen kör stabilt inom simulerat processfönster"

    def estimate_speed_scenario_value(self, speed_increase_percent: float) -> float:
        baseline_shift_packs = self.production.target_packs_per_shift
        efficiency_gain = speed_increase_percent * 0.88 / 100.0
        extra_packs = baseline_shift_packs * efficiency_gain
        extra_margin = extra_packs * self.economy.contribution_margin_per_pack
        added_waste_cost = extra_packs * 0.018 * self.economy.waste_cost_per_pack
        added_energy_cost = self.production.shift_minutes * 0.42 * self.economy.energy_cost_per_kwh
        return extra_margin - added_waste_cost - added_energy_cost


if __name__ == "__main__":
    DashboardApp().run()
