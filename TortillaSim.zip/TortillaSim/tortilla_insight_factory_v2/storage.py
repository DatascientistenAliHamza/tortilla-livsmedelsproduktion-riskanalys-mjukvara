from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path
from typing import Any


class ProductionStorage:
    """Stores the complete simulation trail for analysis after the demo.

    The project deliberately saves both human friendly files and a small SQLite
    database. That makes it easy to inspect the run in Excel, pandas, Power BI
    or any SQL client.
    """

    def __init__(self, output_dir: str = "out") -> None:
        self.output_path = Path(output_dir)
        self.output_path.mkdir(parents=True, exist_ok=True)
        self.database_path = self.output_path / "tortilla_factory.db"
        self.stream_path = self.output_path / "telemetry_stream.csv"
        self.training_path = self.output_path / "training_samples.csv"
        self.events_path = self.output_path / "events.jsonl"
        self.economy_path = self.output_path / "economy_snapshots.csv"
        self.connection = sqlite3.connect(self.database_path)
        self._create_tables()
        self._ensure_csv_headers()

    def _create_tables(self) -> None:
        with self.connection:
            self.connection.execute(
                """
                create table if not exists telemetry (
                    minute integer primary key,
                    sku text,
                    line_state text,
                    ai_active integer,
                    speed_change_percent real,
                    packs_total integer,
                    packs_per_hour real,
                    baseline_packs_per_hour real,
                    throughput_lift_percent real,
                    oee real,
                    quality_score real,
                    risk_probability real,
                    downtime_minutes integer,
                    prevented_stops integer,
                    waste_packs integer,
                    pallets_done integer,
                    belt_speed real,
                    flow_kg_minute real,
                    humidity real,
                    dough_temp real,
                    line_pressure real,
                    oven_z1 real,
                    oven_z2 real,
                    oven_z3 real,
                    film_left integer,
                    energy_kwh real,
                    net_value real
                )
                """
            )
            self.connection.execute(
                """
                create table if not exists events (
                    id integer primary key autoincrement,
                    minute integer,
                    type text,
                    machine text,
                    message text,
                    risk_probability real,
                    ai_active integer
                )
                """
            )
            self.connection.execute(
                """
                create table if not exists training_samples (
                    id integer primary key autoincrement,
                    minute integer,
                    label integer,
                    risk_probability real,
                    features_json text
                )
                """
            )
            self.connection.execute(
                """
                create table if not exists economy_snapshots (
                    minute integer primary key,
                    baseline_packs real,
                    current_packs integer,
                    extra_packs real,
                    extra_margin real,
                    avoided_downtime_value real,
                    waste_cost real,
                    energy_cost real,
                    net_value real
                )
                """
            )

    def _ensure_csv_headers(self) -> None:
        self._ensure_header(
            self.stream_path,
            [
                "minute",
                "sku",
                "line_state",
                "ai_active",
                "speed_change_percent",
                "packs_total",
                "packs_per_hour",
                "baseline_packs_per_hour",
                "throughput_lift_percent",
                "oee",
                "quality_score",
                "risk_probability",
                "downtime_minutes",
                "prevented_stops",
                "waste_packs",
                "pallets_done",
                "belt_speed",
                "flow_kg_minute",
                "humidity",
                "dough_temp",
                "line_pressure",
                "oven_z1",
                "oven_z2",
                "oven_z3",
                "film_left",
                "energy_kwh",
                "net_value",
            ],
        )
        self._ensure_header(
            self.training_path,
            ["minute", "label", "risk_probability", "features_json"],
        )
        self._ensure_header(
            self.economy_path,
            [
                "minute",
                "baseline_packs",
                "current_packs",
                "extra_packs",
                "extra_margin",
                "avoided_downtime_value",
                "waste_cost",
                "energy_cost",
                "net_value",
            ],
        )

    def _ensure_header(self, path: Path, headers: list[str]) -> None:
        if path.exists():
            return
        with path.open("w", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(headers)

    def save_telemetry(self, row: dict[str, Any]) -> None:
        keys = [
            "minute",
            "sku",
            "line_state",
            "ai_active",
            "speed_change_percent",
            "packs_total",
            "packs_per_hour",
            "baseline_packs_per_hour",
            "throughput_lift_percent",
            "oee",
            "quality_score",
            "risk_probability",
            "downtime_minutes",
            "prevented_stops",
            "waste_packs",
            "pallets_done",
            "belt_speed",
            "flow_kg_minute",
            "humidity",
            "dough_temp",
            "line_pressure",
            "oven_z1",
            "oven_z2",
            "oven_z3",
            "film_left",
            "energy_kwh",
            "net_value",
        ]
        values = [row.get(key) for key in keys]
        placeholders = ", ".join("?" for _ in keys)
        columns = ", ".join(keys)
        with self.connection:
            self.connection.execute(
                f"insert or replace into telemetry ({columns}) values ({placeholders})",
                values,
            )
        with self.stream_path.open("a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(values)

    def save_economy(self, row: dict[str, Any]) -> None:
        keys = [
            "minute",
            "baseline_packs",
            "current_packs",
            "extra_packs",
            "extra_margin",
            "avoided_downtime_value",
            "waste_cost",
            "energy_cost",
            "net_value",
        ]
        values = [row.get(key) for key in keys]
        placeholders = ", ".join("?" for _ in keys)
        columns = ", ".join(keys)
        with self.connection:
            self.connection.execute(
                f"insert or replace into economy_snapshots ({columns}) values ({placeholders})",
                values,
            )
        with self.economy_path.open("a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(values)

    def save_event(self, event: dict[str, Any]) -> None:
        with self.connection:
            self.connection.execute(
                """
                insert into events (minute, type, machine, message, risk_probability, ai_active)
                values (?, ?, ?, ?, ?, ?)
                """,
                (
                    event.get("minute"),
                    event.get("type"),
                    event.get("machine", "Line"),
                    event.get("message", ""),
                    event.get("risk_probability", 0.0),
                    int(bool(event.get("ai_active", False))),
                ),
            )
        with self.events_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False) + "\n")

    def save_training_sample(
        self,
        minute: int,
        label: int,
        risk_probability: float,
        features: list[float],
    ) -> None:
        payload = json.dumps([round(float(value), 5) for value in features])
        with self.connection:
            self.connection.execute(
                """
                insert into training_samples (minute, label, risk_probability, features_json)
                values (?, ?, ?, ?)
                """,
                (minute, int(label), float(risk_probability), payload),
            )
        with self.training_path.open("a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow([minute, int(label), round(float(risk_probability), 5), payload])

    def close(self) -> None:
        self.connection.close()
