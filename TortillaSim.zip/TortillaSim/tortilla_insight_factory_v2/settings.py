from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AppSettings:
    title: str = "Tortilla Production Simulator"
    width: int = 1600
    height: int = 960
    fps: int = 60
    seconds_per_sim_minute: float = 0.34
    fast_multiplier: float = 3.0


@dataclass(frozen=True)
class ProductionSettings:
    shift_minutes: int = 480
    target_packs_per_shift: int = 4200
    default_belt_speed: float = 1.25
    minimum_speed_factor: float = 0.70
    maximum_speed_factor: float = 1.35
    speed_step_percent: int = 5
    default_flow_kg_minute: float = 52.0
    default_humidity: float = 35.0
    film_roll_length: int = 9000
    cartons_per_pallet_layer: int = 3
    layers_per_pallet: int = 9
    packs_per_carton_six_pack: int = 18
    packs_per_carton_twelve_pack: int = 12

    @property
    def baseline_packs_per_minute(self) -> float:
        return self.target_packs_per_shift / self.shift_minutes

    @property
    def baseline_packs_per_hour(self) -> float:
        return self.baseline_packs_per_minute * 60.0


@dataclass(frozen=True)
class OvenSettings:
    zone_setpoints: tuple[float, float, float] = (190.0, 212.0, 202.0)
    warning_tolerance: float = 5.5
    stop_tolerance: float = 10.0
    correction_gain: float = 0.42


@dataclass(frozen=True)
class ModelSettings:
    window_minutes: int = 45
    warmup_samples: int = 70
    warning_threshold: float = 0.48
    action_threshold: float = 0.65
    stop_threshold: float = 0.82


@dataclass(frozen=True)
class EconomySettings:
    contribution_margin_per_pack: float = 1.85
    downtime_cost_per_minute: float = 185.0
    waste_cost_per_pack: float = 1.10
    energy_cost_per_kwh: float = 1.45
    planned_shift_labor_cost: float = 13800.0
    baseline_energy_kwh_per_minute: float = 5.20
