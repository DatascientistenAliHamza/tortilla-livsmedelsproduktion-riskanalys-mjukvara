from __future__ import annotations

from collections import deque
from typing import Iterable

import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import StandardScaler

from settings import ModelSettings, OvenSettings, ProductionSettings
from utils import clamp, mean, stdev, trend


class PredictiveMaintenanceModel:
    """Online risk model for the simulated tortilla line.

    The model is designed to be explainable in a portfolio project. It starts
    with a deterministic risk calculation, then lets an online classifier take
    more influence after enough labelled samples have been collected.
    """

    def __init__(self, settings: ModelSettings | None = None) -> None:
        self.settings = settings or ModelSettings()
        self.production = ProductionSettings()
        self.oven = OvenSettings()
        self.scaler = StandardScaler()
        self.classifier = SGDClassifier(
            loss="log_loss",
            penalty="l2",
            alpha=0.0007,
            learning_rate="optimal",
            random_state=42,
        )
        self.feature_buffer: deque[np.ndarray] = deque(maxlen=4000)
        self.label_buffer: deque[int] = deque(maxlen=4000)
        self.is_ready = False
        self.last_features: list[float] = []
        self.last_heuristic = 0.0
        self.last_model_risk = 0.0

    @property
    def samples_seen(self) -> int:
        return len(self.label_buffer)

    @property
    def readiness_percent(self) -> float:
        return clamp(self.samples_seen / self.settings.warmup_samples * 100, 0, 100)

    def build_features(self, history: list[dict], stage_health: Iterable[float]) -> list[float]:
        window = history[-self.settings.window_minutes :]
        if not window:
            return [0.0] * 38

        oven_z1 = [row["oven_z1"] for row in window]
        oven_z2 = [row["oven_z2"] for row in window]
        oven_z3 = [row["oven_z3"] for row in window]
        flow = [row["flow_kg_minute"] for row in window]
        speed = [row["belt_speed"] for row in window]
        humidity = [row["humidity"] for row in window]
        film = [row["film_left"] for row in window]
        pressure = [row["line_pressure"] for row in window]
        dough_temp = [row["dough_temp"] for row in window]
        quality = [row["quality_score"] for row in window]
        energy = [row["energy_kwh"] for row in window]
        waste = [row["waste_packs"] for row in window]
        packs_per_hour = [row["packs_per_hour"] for row in window]
        health = list(stage_health)
        latest = window[-1]

        setpoints = self.oven.zone_setpoints
        oven_gap = max(
            abs(latest["oven_z1"] - setpoints[0]),
            abs(latest["oven_z2"] - setpoints[1]),
            abs(latest["oven_z3"] - setpoints[2]),
        )
        speed_factor = latest["belt_speed"] / self.production.default_belt_speed
        film_ratio = latest["film_left"] / self.production.film_roll_length
        weak_stage_count = sum(1 for value in health if value < 58.0)

        features = [
            mean(oven_z1), stdev(oven_z1), trend(oven_z1),
            mean(oven_z2), stdev(oven_z2), trend(oven_z2),
            mean(oven_z3), stdev(oven_z3), trend(oven_z3),
            mean(flow), stdev(flow), trend(flow),
            mean(speed), stdev(speed), trend(speed), speed_factor,
            mean(humidity), stdev(humidity), trend(humidity),
            mean(film), trend(film), film_ratio,
            oven_gap,
            min(health) if health else 100.0,
            mean(health) if health else 100.0,
            weak_stage_count,
            mean(pressure), stdev(pressure), trend(pressure),
            mean(dough_temp), stdev(dough_temp), trend(dough_temp),
            mean(quality), trend(quality),
            trend(energy),
            mean(waste), trend(waste),
            mean(packs_per_hour),
        ]
        self.last_features = [float(value) for value in features]
        return self.last_features

    def heuristic_risk(self, features: list[float]) -> float:
        if not features:
            return 0.12

        speed_factor = features[15]
        humidity_std = features[17]
        film_ratio = features[21]
        oven_gap = features[22]
        weakest_health = features[23]
        weak_stage_count = features[25]
        line_pressure = features[26]
        pressure_std = features[27]
        quality_score = features[32]
        quality_trend = features[33]
        waste_trend = features[36]

        score = 0.08
        score += clamp((oven_gap - 3.5) / 13.0, 0.0, 0.25)
        score += clamp((0.20 - film_ratio) / 0.20, 0.0, 0.18)
        score += clamp((64.0 - weakest_health) / 58.0, 0.0, 0.24)
        score += clamp((line_pressure - 63.0) / 25.0, 0.0, 0.15)
        score += clamp((84.0 - quality_score) / 24.0, 0.0, 0.14)
        score += clamp((speed_factor - 1.08) / 0.22, 0.0, 0.10)
        score += clamp(humidity_std / 3.5, 0.0, 0.04)
        score += clamp(pressure_std / 7.5, 0.0, 0.05)
        score += clamp(-quality_trend / 0.12, 0.0, 0.06)
        score += clamp(waste_trend / 0.18, 0.0, 0.05)
        score += min(0.10, weak_stage_count * 0.04)
        return clamp(score, 0.02, 0.98)

    def update(self, features: list[float], label: int) -> None:
        x = np.array(features, dtype=float).reshape(1, -1)
        y = int(label)
        self.feature_buffer.append(x.ravel())
        self.label_buffer.append(y)
        self.scaler.partial_fit(x)

        labels = set(self.label_buffer)
        enough_data = len(self.label_buffer) >= self.settings.warmup_samples
        has_both_classes = labels == {0, 1}

        if not self.is_ready:
            if enough_data and has_both_classes:
                x_train = np.vstack(self.feature_buffer)
                y_train = np.array(self.label_buffer)
                self.scaler.fit(x_train)
                self.classifier.partial_fit(
                    self.scaler.transform(x_train),
                    y_train,
                    classes=np.array([0, 1]),
                )
                self.is_ready = True
            return

        self.classifier.partial_fit(self.scaler.transform(x), np.array([y]))

    def predict(self, features: list[float]) -> float:
        heuristic = self.heuristic_risk(features)
        self.last_heuristic = heuristic
        if not self.is_ready:
            self.last_model_risk = heuristic
            return heuristic

        x = np.array(features, dtype=float).reshape(1, -1)
        model_risk = float(self.classifier.predict_proba(self.scaler.transform(x))[0, 1])
        self.last_model_risk = model_risk
        return clamp((0.35 * heuristic) + (0.65 * model_risk), 0.02, 0.98)

    def recommendation(self, features: list[float], ai_active: bool) -> str:
        if not features:
            return "Samlar data och bygger en normalbild för linjen"

        speed_factor = features[15]
        film_ratio = features[21]
        oven_gap = features[22]
        weakest_health = features[23]
        line_pressure = features[26]
        quality_score = features[32]

        prefix = "AI aktiv: " if ai_active else "AI inaktiv: "
        if film_ratio < 0.18:
            return prefix + "planera filmbyte innan påspackaren blir flaskhals"
        if oven_gap > 5.5:
            return prefix + "stabilisera ugnszonerna och minska variationen"
        if line_pressure > 72.0:
            return prefix + "sänk takt tillfälligt eller balansera flödet"
        if weakest_health < 58.0:
            return prefix + "kör mikroservice på svagaste stationen"
        if quality_score < 82.0:
            return prefix + "justera processfönster för att minska svinn"
        if speed_factor > 1.15:
            return prefix + "högre takt fungerar, men följ risk och kvalitet noga"
        return prefix + "linjen är stabil och kan fortsätta övervakas"

    def risk_drivers(self, features: list[float]) -> list[tuple[str, float, str]]:
        if not features:
            return [("Datainsamling", 0.2, "Modellen väntar på mer historik")]

        speed_factor = features[15]
        film_ratio = features[21]
        oven_gap = features[22]
        weakest_health = features[23]
        line_pressure = features[26]
        quality_score = features[32]

        drivers = [
            ("Fart", clamp((speed_factor - 1.05) / 0.25, 0.0, 1.0), "hög takt ökar stress på linjen"),
            ("Film", clamp((0.22 - film_ratio) / 0.22, 0.0, 1.0), "låg filmnivå kan stoppa påspackaren"),
            ("Ugn", clamp(oven_gap / 12.0, 0.0, 1.0), "temperaturdrift påverkar kvalitet"),
            ("Maskinhälsa", clamp((72.0 - weakest_health) / 72.0, 0.0, 1.0), "svaga stationer ökar stopprisken"),
            ("Linjetryck", clamp((line_pressure - 60.0) / 28.0, 0.0, 1.0), "obalanserat flöde skapar flaskhalsar"),
            ("Kvalitet", clamp((90.0 - quality_score) / 28.0, 0.0, 1.0), "lägre kvalitet driver svinn och stopp"),
        ]
        return sorted(drivers, key=lambda item: item[1], reverse=True)[:4]
