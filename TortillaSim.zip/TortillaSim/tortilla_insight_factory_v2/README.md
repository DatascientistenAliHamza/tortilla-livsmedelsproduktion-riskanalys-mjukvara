# Tortilla Production Simulator

Tortilla Production Simulator är ett portfolio projekt som visar hur data science kan användas i en produktionsmiljö. Projektet simulerar en tortillalinje, visualiserar nyckeltal i realtid, sparar data och använder en online modell för att bedöma risken för oplanerade stopp.

Målet är att visa ett system som inte bara presenterar data, utan hjälper produktion, teknik, ekonomi och ledning att förstå vad som händer, varför det händer och vad det kan betyda i pengar.

## Varför projektet finns

I många fabriker finns det redan sensordata, loggar och produktionsmål. Utmaningen är att göra informationen användbar innan ett problem blir dyrt. Detta projekt demonstrerar ett arbetssätt där simulering, prediktivt underhåll, operatörsstöd och ekonomisk analys kopplas ihop i en tydlig dashboard.

Projektet bygger på simulerad data och är inte skapat för verklig drift. Syftet är att visa förmåga att tänka systematiskt, affärsnära och tekniskt samtidigt.

## Vad dashboarden visar

Dashboarden har flera vyer som kan väljas i headern.

1. Översikt visar risk för stopp, OEE, produktionstakt, skiftmål, förebyggda stopp och ekonomisk nettoeffekt.

2. Produktion visar linjestatus, stationernas hälsa, takt mot standard och processdata som ugnstemperatur, tryck och bandhastighet.

3. AI visar om prevention är aktiv eller inaktiv, hur modellen tränas och vilka riskdrivare som påverkar beslutet.

4. Ekonomi visar hur fart, extra volym, svinn, energi och undvikna stopp påverkar resultatet.

5. Logg visar händelser som stopp, återstart, batchbyte, manuella tester och förebyggande åtgärder.

## Viktiga funktioner

1. Klickbar ljus dashboard byggd med Pygame.

2. Header där användaren kan välja vilken vy som ska visas.

3. Informationssymbol vid varje knapp som förklarar vad funktionen gör.

4. AI knapp som tydligt växlar mellan Aktiv och Inaktiv.

5. Hastighetsstyrning i procent mot standardläge.

6. KPI som visar hur produktionen förändras när hastigheten höjs eller sänks.

7. Ekonomivy som översätter produktion, stopp, svinn och energi till kronor.

8. Simulerad produktionslinje med maskinhälsa, stopp, återstart och förebyggande åtgärder.

9. Online maskininlärning med partial fit där modellen tränas under körning.

10. Sparande av telemetri, träningsdata, händelser och ekonomiska snapshots.

## Simuleringens idé

Linjen består av flera stationer från råvaror till pall. Varje station har hälsa, kritikalitet, simulerad felrisk och återställningstid. Under körning förändras flöde, luftfuktighet, degtemperatur, ugnszoner, linjetryck, filmnivå, energiförbrukning och kvalitet.

När hastigheten ökar kan produktionen öka, men samtidigt kan linjetryck, slitage, risk, energi och svinn öka. Det gör att dashboarden inte bara visar mer produktion, utan även konsekvensen av att pressa linjen hårdare.

## AI prevention

AI prevention kan vara Aktiv eller Inaktiv.

När AI är Aktiv kan systemet själv utföra förebyggande åtgärder om risken blir hög. Det kan till exempel vara att stabilisera ugnszoner, planera filmbyte, sänka takt tillfälligt eller utföra mikroservice på en svag station.

När AI är Inaktiv fortsätter systemet att samla data och visa risk, men inga automatiska åtgärder utförs. Det gör det enkelt att demonstrera skillnaden mellan ett passivt övervakningssystem och ett aktivt beslutsstöd.

## Ekonomisk logik

Ekonomivyn jämför nuvarande körning mot ett standardläge. Standardläget bygger på normal bandhastighet och ett skiftmål på 4200 paket.

Systemet beräknar bland annat:

1. Extra paket jämfört med standardläge.

2. Extra marginal från ökad volym.

3. Undviken stoppkostnad från förebyggande åtgärder.

4. Kostnad för svinn.

5. Extra energikostnad över standard.

6. Simulerad nettoeffekt.

Detta gör projektet mer relevant för flera roller. Operatörer kan se linjestatus, tekniker kan se riskdrivare, produktionschefer kan se takt och OEE, och ekonomer kan se möjlig påverkan på resultat.

## Data som sparas

När programmet körs skapas mappen out. Där sparas all simulerad data.

```text
out/tortilla_factory.db
out/telemetry_stream.csv
out/training_samples.csv
out/economy_snapshots.csv
out/events.jsonl
```

Det gör det enkelt att analysera körningen i pandas, Power BI, Excel eller SQL.

## Kom igång

Skapa en virtuell miljö och installera beroenden.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

På Windows aktiveras miljön så här.

```bash
.venv\Scripts\activate
```

Starta dashboarden.

```bash
python main.py
```

## Kontroller

```text
Space  Pausa eller starta
F      Demo x3 eller normal takt
A      Växla AI mellan Aktiv och Inaktiv
W      Öka farten med fem procent
S      Sänk farten med fem procent
P      Kör förebyggande åtgärd manuellt
I      Injicera ett simulerat fel
R      Återställ simuleringen
1 till 5  Växla vy i dashboarden
```

Alla funktioner finns även som klickbara knappar längst ned i dashboarden.

## Projektstruktur

```text
main.py           Dashboard, vyer, knappar och interaktion
simulation.py     Produktionslogik, stopp, flöde och ekonomi
model.py          Online modell och riskdrivare
storage.py        SQLite, CSV och JSONL lagring
settings.py       Inställningar för produktion, AI och ekonomi
utils.py          Hjälpfunktioner
requirements.txt  Python beroenden
```

## Förslag på GitHub demo

En bra demo video kan vara cirka en minut.

1. Visa översikten och förklara att systemet följer risk, OEE, takt och ekonomi.

2. Gå till Produktion och höj farten med fem procent.

3. Visa att KPI ändras mot standardläge.

4. Gå till AI och slå AI från Aktiv till Inaktiv.

5. Injicera ett fel och visa hur riskdrivare och logg uppdateras.

6. Slå AI Aktiv igen och kör Förebygg nu.

7. Avsluta i Ekonomi och visa hur undvikna stopp och extra volym påverkar nettoeffekten.

## Kort pitch

Det här projektet visar hur jag tänker som datascientist. Jag bygger inte bara grafer, utan ett system som kopplar ihop data, processförståelse, maskininlärning och affärsvärde. Fokus är att skapa insikt som kan användas innan produktionen tappar tid, kvalitet eller pengar.
